package io.jenkins.tools.pluginmanager.config;

public enum OutputFormat {
    STDOUT, YAML, TXT
}
